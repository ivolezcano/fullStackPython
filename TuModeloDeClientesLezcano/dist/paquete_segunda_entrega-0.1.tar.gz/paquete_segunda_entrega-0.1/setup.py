from setuptools import setup

setup(
    name='paquete_segunda_entrega',
    version='0.1',
    description='Paquete de la segunda entrega del curso de Python',
    author='Ivan Lezcano',
    author_email='lezcamati@gmail.com', 
    packages=['segunda_entrega'],
)

